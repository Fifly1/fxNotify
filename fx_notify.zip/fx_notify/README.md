Hello, thank you for buying this script.
To call a notification do this:

|Client Side|

exports['fx_notify']:fx_notify("type", "title", "message", time)	

|Server side|

TriggerClientEvent('fx_notify:Notify', source, "type", "title", "message", Time)

Notification types:
 - success
 - info
 - error
 - warning

 If you have any problems, questions or ideas you can make a ticket in the Discord server.
